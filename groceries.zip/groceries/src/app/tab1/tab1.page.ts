import { Component } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';



@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  tabtitle = "Grocery List";
  items = [
    {
      name: "Milk",
      quantity: 1
    },
    {
      name: "Bread",
      quantity: 2
    },
    {
      name: "Eggs",
      quantity: 3
    },

  

  ];
  constructor(public toastController: ToastController, public alertController: AlertController) {

  }  
  
  async presentToast(item, index) {
    const toast = await this.toastController.create({
      message: 'your item has been removed from the list' ,
      duration: 2000
    });
    toast.present();

    this.items.splice(index,1);
  }
  
  additem() {
    console.log("Item Added")
    this.presentAlertPrompt()
  }

  async presentAlertPrompt() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Add Grocery Item',
      inputs: [
        {
          name: 'name',
          type: 'text',
          placeholder: 'New Item'
        },
        {
          name: 'quantity',
          type: 'number',
          placeholder: 'quantity'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Save',
          handler: item => {
            console.log('Save', item);
            this.items.push(item);
          }
        }
      ]
    });

    await alert.present();
  }



}



